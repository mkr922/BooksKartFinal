package com.ts.BooksKart;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.dao.BookDao;
import com.dao.UserDao;
import com.model.Book;
import com.model.User;

@RestController
public class BookController {
	
	@Autowired
	BookDao bookDao;
	
	@Autowired
	UserDao userDao;
	
	@RequestMapping("/addBooks")
	public String addBooks(){
//		[{"userId":1,"userName":"kondareddy","emailId":"munagalakondareddy@gmail.com","mobile":"9000760995","address":"guntur","loginId":"mkr123","password":"password"}]
		
		User user1 = new User("kondareddy","munagalakondareddy@gmail.com","9000760995","guntur","mkr123","password");
		user1.setUserId(1);
		
		User user2 = new User("ram","ram123@gmail.com","982342234","guntur","ram123","password");
		user2.setUserId(2);
		
		User user3 = new User("krishna","krishna123@gmail.com","982342235","guntur","krishna123","password");
		user3.setUserId(3);
//		Book( String bookName, String author, String edition, int year, double price, String description,
//				String availability, String category, String imagePath) 
		Book book1 = new Book("Richest Man In Babylona", "clason", "12th",2019, 150, "it's about the tale of a babylona city",
				"In Stock", "Finance","richestman.jpg");
		book1.setUser(user1);
			
		Book book2 = new Book("beat wallstreet", "mayor", "12th",2019, 150, "it's about how to beat market",
				"In Stock", "Finance","wallstreet.jpg");
		book2.setUser(user2);
		
//		Book book3 = new Book("Once upon a time", "medal", "12th",2019, 150, "wall street ",
//				"In Stock", "history");
//		book3.setUser(user3);
//		
		
		
		List<Book> bookList = new ArrayList<Book>();
		bookList.add(book1);
		bookList.add(book2);
//		bookList.add(book3);
		
		bookDao.addBook(book1);
		
		return "registration succesful";
	}
	
	@RequestMapping("/showAllBooks")
	public List <Book> showAllBooks(){
		
		List<Book> bookList = bookDao.getBooks();		
		return bookList;
	}
	
	@RequestMapping("/getMyBooks/{userId}")
	public List <Book> showMyBooks(@PathVariable("userId") int userId){
		System.out.println("coming for the mybooks"+userId);
		List<Book> bookList = bookDao.getMyBooks(userId);		
		return bookList;
	}
	
	@RequestMapping("/showBookByName/{bookName}")
	public Book showProductByName(@PathVariable("bookName") String bookName){		
		Book book = bookDao.getProductByName(bookName);
		return book;
	}
	
	@PostMapping("/upLoadBook")
	public void uploadBook(@RequestPart("Image") MultipartFile file,
			@RequestParam("bookName") String bookName,
			@RequestParam("author") String author,
			@RequestParam("edition") String edition, @RequestParam("year") int year,@RequestParam("price") double price,
			@RequestParam("description") String description,@RequestParam("availability") String availability,
			@RequestParam("category") String category, @RequestParam("loginId") String loginId,@RequestParam("password") String password) throws IOException {
		
		System.out.println("Upload called...");

		Path root = Paths.get("src/main/resources/uploads");
		//Files.createDirectory(root);
	      //System.out.println(root+" : "+file.getOriginalFilename());
	      
	      Files.copy(file.getInputStream(), root.resolve(file.getOriginalFilename()));	  
	      System.out.println(loginId+""+password);
	     
	      User user = userDao.getUser(loginId,password);
	      Book book =  new Book(bookName,  author,  edition,  year, price, description,
		  			availability,  category, file.getOriginalFilename()) ;
	      book.setUser(user);
	   
	      bookDao.addBook(book);
		
}
	
	@RequestMapping("/updateBook")
	public void updateBook(@RequestBody Book book){
		System.out.println("Data Received From Angular for Updating Employee");
		System.out.println(book);
		bookDao.updateBook(book);
		
	}

@RequestMapping(value = "/showImage/{imageName}", method = RequestMethod.GET,
	            produces = MediaType.IMAGE_JPEG_VALUE)
public void getImage(HttpServletResponse response,@PathVariable("imageName") String imageName) throws IOException {

	        ClassPathResource imgFile = new ClassPathResource("uploads/"+imageName);
	        response.setContentType(MediaType.IMAGE_JPEG_VALUE);
	        StreamUtils.copy(imgFile.getInputStream(), response.getOutputStream());
}
	

}
