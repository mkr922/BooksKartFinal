package com.ts.BooksKart;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.OrderDetaisDao;
import com.dao.UserDao;
import com.model.Book;
import com.model.OrderDetails;
import com.model.Orders;
import com.model.User;

@RestController
public class OrderDetailsController {
	
	@Autowired
	OrderDetaisDao orderDetailsDao;
	
	
	
	@RequestMapping("/setOrderDetails")
	public String giveOrderDetails(){
		
		OrderDetails orderDetails = new OrderDetails(1, 150);
		
		User user1 = new User("mkr","munagala@gmail.com","982342233","guntur","mkr123","password");
		user1.setUserId(1);
		
		Orders order1 = new Orders("Pending",new Date(2021-04-03));
		order1.setOrderId(1);
		order1.setUser(user1);
		
		orderDetails.setOrder(order1);
	
		User user2 = new User("ram","ram123@gmail.com","982342234","guntur","ram123","password");
		user2.setUserId(2);
//		
//		book2.setBookId(2);
//		book2.setUser(user2);
//		
//		orderDetails.setBook(book2);
		
		orderDetailsDao.setOrderDetails(orderDetails);
		
		return "succesfully given orders" ;
	}
	
	@RequestMapping("/showOrderDetails")
	public List<OrderDetails> showOrderDetails(){
	
		return orderDetailsDao.showOrderDetails();
	}
	
	

}
