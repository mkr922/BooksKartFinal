package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Orders;

@Service
public class OrdersDao {

	@Autowired
	OrdersRepository ordersRepository;
	public Orders makeOrder(Orders order) {
		
		return ordersRepository.save(order);
	}
	
	public List<Orders> showOrders() {
		return ordersRepository.findAll();
	}

	public Orders getOrder() {
		return ordersRepository.lastOrder();
	}

}
