package com.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.model.Book;

public interface BookRepository extends JpaRepository<Book, Integer>{

	Optional<Book> findByBookName(String bookName);
	
	@Query("select b from Book b WHERE user_id = ?1")
	List<Book> findAllBooksById(@Param("userId") int userId);

}
