package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Book;
import com.model.User;

@Service
public class BookDao {
	
	@Autowired
	BookRepository bookRepository;

	public void addBook(Book book) {
		bookRepository.save(book);
		System.out.println("added");
	}

	public List<Book> getBooks() {
		return bookRepository.findAll();
	}

	public Book getProductByName(String bookName) {
		Book book = bookRepository.findByBookName(bookName).orElse(new Book());
		return book;
	}

	public List<Book> getMyBooks(int userId) {
		List<Book> bookList = bookRepository.findAllBooksById(userId);
		return bookList;
	}

	public Object updateBook(Book book) {
		bookRepository.save(book);
		return "updated";
	}

}
