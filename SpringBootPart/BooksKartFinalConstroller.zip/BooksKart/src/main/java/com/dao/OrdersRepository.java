package com.dao;


import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.model.Orders;


public interface OrdersRepository extends JpaRepository<Orders, Integer> {
	@Query(nativeQuery = true,
		       value = "select * from orders order by order_id desc limit 1; ")
	Orders lastOrder();

}
